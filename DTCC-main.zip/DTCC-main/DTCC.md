Depository Trust Clearing Corporation(DTCC) settlement services offered through [[DTC]] reduce cost and risk and boost efficiencies in the marketplace by providing end-of-day ([[EOD]]) net settlement obligations for clients resulting from trading activity in equities, debt and money market instruments. [[Asset]] Servicing, also offered through DTC, offers a broad range of services for [[underwriting]], [[Custody]], corporate actions, dividend, [[Proxy]] and reorganization services, as well as the electronic registration and transfer of securities. 

DTC is a [[Member]] of the [[U.S. Federal Reserve System]], a limited-purpose trust company under New York State banking law and a registered clearing agency with the U.S. [[Securities and Exchange Commission]]([[SEC]]).
https://www.dtcc.com/about/businesses-and-subsidiaries/dtc

A rather telling statement, and could explain the lack of SEC enforcement on retails behalf; **Who Owns DTCC?**

DTCC is owned by its customers, which are members of the financial community such as banks, broker/dealers, mutual funds and other financial institutions. DTCC operates on an at-cost basis, returning excess revenue from transaction fees to its [[Member]] firms.

https://www.sechistorical.org/collection/papers/2010/2010_0701_DTCCServices.pdf